# STM32F103CAN Library

This library provides an easy-to-use interface for CAN communication on STM32F103 series microcontrollers.

## Features

- Support for both CAN1 and CAN2 interfaces
- Configurable baud rates
- Support for standard and extended CAN IDs
- Simple send and receive functions

## Installation

1. Download the ZIP file of this library
2. In Arduino IDE, go to Sketch > Include Library > Add .ZIP Library...
3. Select the downloaded ZIP file

## Usage

See the included example in the `examples` folder for basic usage.

## License

This library is released under the MIT License. See the included LICENSE file for details.

## Contributing

Contributions to this library are welcome. Please submit pull requests or open issues on the GitHub repository.