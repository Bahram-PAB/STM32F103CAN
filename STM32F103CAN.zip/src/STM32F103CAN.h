#ifndef STM32F103CAN_H
#define STM32F103CAN_H

#include <Arduino.h>

class STM32F103CAN {
public:
    enum CANSpeed {
        CAN_1000KBPS,
        CAN_500KBPS,
        CAN_250KBPS,
        CAN_125KBPS,
        CAN_100KBPS
    };

    enum CANPort {
        CAN_1,
        CAN_2
    };

    struct CANMessage {
        uint32_t id;
        bool extended;
        bool rtr;
        uint8_t length;
        uint8_t data[8];
    };

    STM32F103CAN(CANPort port = CAN_1);
    bool begin(CANSpeed speed, uint8_t rx_pin, uint8_t tx_pin);
    void setID(uint32_t id, bool extended = false);
    bool send(uint8_t* data, uint8_t length);
    bool receive(CANMessage &msg);

private:
    uint32_t _id;
    bool _extended;
    bool _initialized;
    CANPort _port;
    CAN_TypeDef* _CANx;
    uint8_t _rx_pin;
    uint8_t _tx_pin;
};

#endif