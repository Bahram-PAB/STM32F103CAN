#include "STM32F103CAN.h"

STM32F103CAN::STM32F103CAN(CANPort port) : _id(0), _extended(false), _initialized(false), _port(port) {
    _CANx = (_port == CAN_1) ? CAN1 : CAN2;
}

bool STM32F103CAN::begin(CANSpeed speed, uint8_t rx_pin, uint8_t tx_pin) {
    _rx_pin = rx_pin;
    _tx_pin = tx_pin;
    
    pinMode(_rx_pin, INPUT);
    pinMode(_tx_pin, AF_OUTPUT_PUSHPULL);

    if (_port == CAN_1) {
        RCC->APB1ENR |= RCC_APB1ENR_CAN1EN;
    } else {
        RCC->APB1ENR |= RCC_APB1ENR_CAN2EN;
    }

    _CANx->MCR |= CAN_MCR_INRQ;
    while(!(_CANx->MSR & CAN_MSR_INAK));

    _CANx->MCR &= ~CAN_MCR_SLEEP;

    uint32_t prescaler;
    switch(speed) {
        case CAN_1000KBPS: prescaler = 4; break;
        case CAN_500KBPS:  prescaler = 8; break;
        case CAN_250KBPS:  prescaler = 16; break;
        case CAN_125KBPS:  prescaler = 32; break;
        case CAN_100KBPS:  prescaler = 40; break;
        default: return false;
    }

    _CANx->BTR = (prescaler - 1) | (11 << 16) | (2 << 20) | (3 << 24);

    _CANx->MCR &= ~CAN_MCR_INRQ;
    while(_CANx->MSR & CAN_MSR_INAK);

    _CANx->IER |= CAN_IER_FMPIE0;

    _initialized = true;
    return true;
}

void STM32F103CAN::setID(uint32_t id, bool extended) {
    _id = id;
    _extended = extended;
}

bool STM32F103CAN::send(uint8_t* data, uint8_t length) {
    if(!_initialized) return false;
    if(length > 8) length = 8;

    while((_CANx->TSR & CAN_TSR_TME0) == 0);

    if (_extended) {
        _CANx->sTxMailBox[0].TIR = (_id << 3) | 0x4;
    } else {
        _CANx->sTxMailBox[0].TIR = (_id << 21) | 0x1;
    }
    _CANx->sTxMailBox[0].TDTR = length;

    _CANx->sTxMailBox[0].TDLR = (data[3] << 24) | (data[2] << 16) | (data[1] << 8) | data[0];
    _CANx->sTxMailBox[0].TDHR = (data[7] << 24) | (data[6] << 16) | (data[5] << 8) | data[4];

    _CANx->sTxMailBox[0].TIR |= 0x1;

    while((_CANx->TSR & CAN_TSR_RQCP0) == 0);

    _CANx->TSR |= CAN_TSR_RQCP0;

    return true;
}

bool STM32F103CAN::receive(CANMessage &msg) {
    if(!_initialized) return false;

    if(_CANx->RF0R & CAN_RF0R_FMP0) {
        msg.id = _CANx->sFIFOMailBox[0].RIR >> 21;
        msg.extended = (_CANx->sFIFOMailBox[0].RIR & 0x4) ? true : false;
        msg.rtr = (_CANx->sFIFOMailBox[0].RIR & 0x2) ? true : false;
        msg.length = _CANx->sFIFOMailBox[0].RDTR & 0xF;

        msg.data[0] = _CANx->sFIFOMailBox[0].RDLR & 0xFF;
        msg.data[1] = (_CANx->sFIFOMailBox[0].RDLR >> 8) & 0xFF;
        msg.data[2] = (_CANx->sFIFOMailBox[0].RDLR >> 16) & 0xFF;
        msg.data[3] = (_CANx->sFIFOMailBox[0].RDLR >> 24) & 0xFF;
        msg.data[4] = _CANx->sFIFOMailBox[0].RDHR & 0xFF;
        msg.data[5] = (_CANx->sFIFOMailBox[0].RDHR >> 8) & 0xFF;
        msg.data[6] = (_CANx->sFIFOMailBox[0].RDHR >> 16) & 0xFF;
        msg.data[7] = (_CANx->sFIFOMailBox[0].RDHR >> 24) & 0xFF;

        _CANx->RF0R |= CAN_RF0R_RFOM0;

        return true;
    }

    return false;
}